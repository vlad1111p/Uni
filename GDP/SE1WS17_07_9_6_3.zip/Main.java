public class Main {
	
	public static void main(String[] args) {
		Spielfeld spielFeld = new Spielfeld(800, 600);
		Gui.create(spielFeld);
	}

}
