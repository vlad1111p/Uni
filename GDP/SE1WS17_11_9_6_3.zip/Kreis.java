public class Kreis extends Figur {
    private Vec2 mittelpunkt;
    private double radius;

    public Kreis(Vec2 mittelpunkt, int radius) {
        this.mittelpunkt = mittelpunkt;
        this.radius = radius;
    }

    @Override
    public void zeichnen(SEGraphics seg) {
        super.zeichnen(seg);
        seg.drawCircle(mittelpunkt.x, mittelpunkt.y, radius);
    }

    @Override
    public double abstandZu(Vec2 p) {
        return Math.max(0, mittelpunkt.distanceTo(p) - radius);
    }


    @Override
    public void verschiebenUm(Vec2 delta) {
        mittelpunkt = mittelpunkt.plus(delta);
    }

    public Vec2 getMittelpunkt() {
        return mittelpunkt;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

}
