public class Rechteck extends Figur {
    private Vec2 start;
    private Vec2 groesse;

    public Rechteck(Vec2 start, Vec2 groesse) {
        this.start = start;
        this.groesse = groesse;
    }

    @Override
    public void zeichnen(SEGraphics seg) {
        super.zeichnen(seg);
        seg.drawRect(start.x, start.y, groesse.x, groesse.y);
    }


    @Override
    public double abstandZu(Vec2 p) {
        Vec2 untenLinks = new Vec2(start.x, start.y + groesse.y);
        Vec2 obenRechts = new Vec2(start.x+groesse.x, start.y);
        Vec2 untenRechts = start.plus(groesse);
        if (p.x < start.x) {
            // Links vom Rechteck
            return p.distanceToLine(start, untenLinks);
        } else if (p.x > start.x + groesse.x) {
            // Rechts vom Rechteck
            return p.distanceToLine(obenRechts, untenRechts);
        } else {
            // x-Koordinate im Rechteck
            if (p.y < start.y) {
                // Oberhalb des Rechtecks
                return p.distanceToLine(start, obenRechts);
            } else if (p.y > start.y + groesse.y) {
                // Unterhalb des Rechtecks
                return p.distanceToLine(untenLinks, untenRechts);
            } else {
                // Im Rechteck
                return 0;
            }
        }
    }


    @Override
    public void verschiebenUm(Vec2 delta) {
        start = start.plus(delta);
    }


    public void setStart(Vec2 start) {
        this.start = start;
    }


    public void setGroesse(Vec2 groesse) {
        this.groesse = groesse;
    }


    public Vec2 getGroesse() {
        return groesse;
    }

}
