public class ZeichenToolRechteck extends ZeichenTool {

    private Rechteck reckteck;
    private Vec2 startPunkt;

    @Override
    public String getName() {
        return "Rechteck";
    }

    @Override
    public void start(Vec2 pos) {
        reckteck = new Rechteck(pos, new Vec2(1, 1));
        startPunkt = pos;
        zeichenBlatt.addFigur(reckteck);
    }

    @Override
    public void ziehen(Vec2 pos) {
        double startX = Math.min(startPunkt.x, pos.x);
        double startY = Math.min(startPunkt.y, pos.y);
        reckteck.setStart(new Vec2(startX, startY));
        double groesseX = Math.abs(startPunkt.x - pos.x);
        double groesseY = Math.abs(startPunkt.y - pos.y);
        reckteck.setGroesse(new Vec2(groesseX, groesseY));
    }

}
