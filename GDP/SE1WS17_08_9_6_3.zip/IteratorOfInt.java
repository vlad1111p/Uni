
interface IteratorOfInt {
	public boolean hasNext();
	public int next();
	
}
