
interface ListOfInt {
	public void add(int element);
	public int get(int index);
	public int size();
	IteratorOfInt iterator();
}
