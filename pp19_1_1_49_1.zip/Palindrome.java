import java.util.Arrays;

public class Palindrome {
	public static boolean isPalindrome(char[] a) {
		
		
		if (a.length < 2) {
     
            return true;
        }

		
		if (Character.toLowerCase(a[0]) != Character.toLowerCase(a[a.length-1])) {

            return false;
        }

        return isPalindrome(Arrays.copyOfRange(a, 1, a.length - 1));
    }

}
