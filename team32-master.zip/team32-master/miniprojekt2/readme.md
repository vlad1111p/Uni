Dies ist ein [Gradle](https://gradle.org/) Projekt.

Sie können das Projekt mit dem folgenden Befehl kompilieren und die Tests ausführen:

    gradle test
    
Zum Starten der main-Methode in der Klass App gibt es den Befehl:

    gradle run --console=plain
    
    
### Projektstruktur

Der Code befindet sich unter `src/main/java/map` und die Tests unter `src/test/java/map`.