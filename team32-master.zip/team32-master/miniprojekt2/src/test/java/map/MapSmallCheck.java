package map;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import smallcheck.SmallCheckRunner;
import smallcheck.annotations.Property;
import smallcheck.annotations.StaticFactory;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.TreeMap;


/**
 * Hier werden die Implementierungen systematisch mit kleinen Beispielen getestet.
 */
@RunWith(SmallCheckRunner.class)
public class MapSmallCheck {

    @Ignore
    @Property(maxDepth = 30, maxInvocations = 1000000)
    @StaticFactory(CommandFactory.class)
    public void testBinarySearchTree(List<Command> commands) {
        simulate(new BinarySearchTree<>(Comparator.naturalOrder()), commands);
    }

    @Ignore
    @Property(maxDepth = 30, maxInvocations = 1000000)
    @StaticFactory(CommandFactoryWithRemove.class)
    public void testBinarySearchTreeWithRemove(List<Command> commands) {
        simulate(new BinarySearchTree<>(Comparator.naturalOrder()), commands);
    }

    @Ignore
    @Property(maxDepth = 30, maxInvocations = 1000000)
    @StaticFactory(CommandFactory.class)
    public void testRedBlackTree(List<Command> commands) {
        simulate(new RedBlackTree<>(Comparator.naturalOrder()), commands);
    }

    @Ignore
    @Property(maxDepth = 30, maxInvocations = 1000000)
    @StaticFactory(CommandFactoryWithRemove.class)
    public void testRedBlackTreeWithRemove(List<Command> commands) {
        simulate(new RedBlackTree<>(Comparator.naturalOrder()), commands);
    }

    private void simulate(Map<String, Integer> m, List<Command> commands) {
        Model model = new Model();

        for (int i = 0; i < commands.size(); i++) {
            Command command = commands.get(i);
            Object res;
            try {
                res = command.execute(m);
            } catch (Exception e) {
                StringBuilder msg = errorMessage(m, commands, i, command);
                msg.append("Exception when executing ");
                command.print(msg);
                msg.append(":\n");
                printException(e, msg);
                Assert.fail(msg.toString());
                return;
            }
            Object mres = command.execute(model);
            if (res instanceof Entry<?, ?>) {
                //noinspection unchecked
                res = modelEntry((Entry) res);
            }
            if (!Objects.equals(res, mres)) {
                StringBuilder msg = errorMessage(m, commands, i, command);
                msg.append("// Expected ").append(mres).append(" but got ").append(res);
                Assert.fail(msg.toString());
            }
        }

    }

    private void printException(Exception e, StringBuilder msg) {
        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));
        msg.append(sw.toString());
    }

    private StringBuilder errorMessage(Map<String, Integer> a, List<Command> commands, int i, Command command) {
        StringBuilder msg = new StringBuilder();
        msg.append("// Failing test:\n");
        msg.append("Map<String, Integer> a = new ").append(a.getClass().getSimpleName()).append("<>(Comparator.naturalOrder());\n");
        for (int j = 0; j < i; j++) {
            commands.get(j).print(msg);
            msg.append(";\n");
        }
        command.print(msg);
        msg.append("\n");
        return msg;
    }

    public static class CommandFactory {
        public static Command put(String key, int value) {
            return new Command() {
                @Override
                Object execute(Map<String, Integer> map) {
                    map.put(key, value);
                    return null;
                }

                @Override
                void print(StringBuilder sb) {
                    sb.append("map.put(\"")
                        .append(key)
                        .append("\", ")
                        .append(value)
                        .append(")");
                }
            };
        }

        public static Command get(String key) {
            return new Command() {
                @Override
                Object execute(Map<String, Integer> map) {
                    return map.get(key);
                }

                @Override
                void print(StringBuilder sb) {
                    sb.append("map.get(\"")
                        .append(key)
                        .append("\")");
                }
            };
        }

        public static Command firstEntry() {
            return new Command() {
                @Override
                Object execute(Map<String, Integer> map) {
                    return map.firstEntry();
                }

                @Override
                void print(StringBuilder sb) {
                    sb.append("map.firstEntry()");
                }
            };
        }


        public static Command ceilingEntry(String key) {
            return new Command() {
                @Override
                Object execute(Map<String, Integer> map) {
                    return map.ceilingEntry(key);
                }

                @Override
                void print(StringBuilder sb) {
                    sb.append("map.ceilingEntry(\"").append(key).append("\")");
                }
            };
        }

        public static Command higherEntry(String key) {
            return new Command() {
                @Override
                Object execute(Map<String, Integer> map) {
                    return map.ceilingEntry(key);
                }

                @Override
                void print(StringBuilder sb) {
                    sb.append("map.higherEntry(\"").append(key).append("\")");
                }
            };
        }
    }

    public static class CommandFactoryWithRemove {
        public static Command put(String key, int value) {
            return CommandFactory.put(key, value);
        }

        public static Command get(String key) {
            return CommandFactory.get(key);
        }

        public static Command remove(String key) {
            return new Command() {
                @Override
                Object execute(Map<String, Integer> map) {
                    map.remove(key);
                    return null;
                }

                @Override
                void print(StringBuilder sb) {
                    sb.append("map.remove(\"")
                        .append(key)
                        .append("\")");
                }
            };
        }

        public static Command firstEntry() {
            return CommandFactory.firstEntry();
        }


        public static Command ceilingEntry(String key) {
            return CommandFactory.ceilingEntry(key);
        }

        public static Command higherEntry(String key) {
            return CommandFactory.higherEntry(key);
        }
    }

    static abstract class Command {
        abstract Object execute(Map<String, Integer> map);

        abstract void print(StringBuilder sb);

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            print(sb);
            return sb.toString();
        }
    }


    private static class Model implements Map<String, Integer> {
        private java.util.TreeMap<String, Integer> m = new TreeMap<>();

        @Override
        public void put(String key, Integer value) {
            m.put(key, value);
        }

        @Override
        public Integer get(String key) {
            return m.get(key);
        }

        @Override
        public void remove(String key) {
            m.remove(key);
        }

        @Override
        public Entry<String, Integer> firstEntry() {
            return modelEntry(m.firstEntry());
        }

        @Override
        public Entry<String, Integer> ceilingEntry(String key) {
            return modelEntry(m.ceilingEntry(key));
        }

        @Override
        public Entry<String, Integer> higherEntry(String key) {
            return modelEntry(m.higherEntry(key));
        }


    }

    private static Entry<String, Integer> modelEntry(java.util.Map.Entry<String, Integer> e) {
        if (e == null) {
            return null;
        }
        return new ModelEntry(e.getKey(), e.getValue());
    }

    private static Entry<String, Integer> modelEntry(Entry<String, Integer> e) {
        if (e == null) {
            return null;
        }
        return new ModelEntry(e.getKey(), e.getValue());
    }

    private static class ModelEntry implements Entry<String, Integer> {
        private final String key;
        private final Integer value;

        public ModelEntry(String key, Integer value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String getKey() {
            return key;
        }

        @Override
        public Integer getValue() {
            return value;
        }

        @Override
        public String toString() {
            return "(\"" + key + "\", " + value + ")";
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            ModelEntry modelEntry = (ModelEntry) o;
            return Objects.equals(key, modelEntry.key) &&
                Objects.equals(value, modelEntry.value);
        }

        @Override
        public int hashCode() {
            return Objects.hash(key, value);
        }
    }

}
