package map;


import org.junit.Ignore;
import org.junit.Test;

import java.util.Comparator;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

public class RedBlackTreeTest {

    private Map<String, String> newInstance() {
        return new RedBlackTree<>(Comparator.naturalOrder());
    }


    @Ignore
    @Test
    public void getEmptyTest() {
        Map<String, String> m = newInstance();
        assertNull(m.get("a"));
    }

    @Ignore
    @Test
    public void putGetTest1() {
        Map<String, String> m = newInstance();
        m.put("a", "x");
        assertEquals("x", m.get("a"));
    }

    @Ignore
    @Test
    public void putGetTest2() {
        Map<String, String> m = newInstance();
        m.put("a", "1");
        m.put("b", "2");
        m.put("c", "3");
        m.put("d", "4");
        m.put("e", "5");
        m.put("f", "6");
        m.put("g", "7");
        assertEquals("1", m.get("a"));
        assertEquals("2", m.get("b"));
        assertEquals("3", m.get("c"));
        assertEquals("4", m.get("d"));
        assertEquals("5", m.get("e"));
        assertEquals("6", m.get("f"));
        assertEquals("7", m.get("g"));
    }

    @Ignore
    @Test
    public void putGetTest3() {
        Map<String, String> m = newInstance();
        m.put("g", "7");
        m.put("f", "6");
        m.put("e", "5");
        m.put("d", "4");
        m.put("c", "3");
        m.put("b", "2");
        m.put("a", "1");
        assertEquals("1", m.get("a"));
        assertEquals("2", m.get("b"));
        assertEquals("3", m.get("c"));
        assertEquals("4", m.get("d"));
        assertEquals("5", m.get("e"));
        assertEquals("6", m.get("f"));
        assertEquals("7", m.get("g"));
    }

    @Ignore
    @Test
    public void putGetTest4() {
        Map<String, String> m = newInstance();
        m.put("d", "4");
        m.put("f", "6");
        m.put("a", "1");
        m.put("e", "5");
        m.put("c", "3");
        m.put("g", "7");
        m.put("b", "2");
        assertEquals("1", m.get("a"));
        assertEquals("2", m.get("b"));
        assertEquals("3", m.get("c"));
        assertEquals("4", m.get("d"));
        assertEquals("5", m.get("e"));
        assertEquals("6", m.get("f"));
        assertEquals("7", m.get("g"));
    }

    @Ignore
    @Test
    public void putGetOverrideTest() {
        Map<String, String> m = newInstance();
        m.put("a", "x");
        m.put("a", "y");
        assertEquals("y", m.get("a"));
    }

    @Ignore
    @Test
    public void removeTest1() {
        Map<String, String> m = newInstance();
        m.put("a", "1");
        m.remove("a");
        assertNull(m.get("a"));
    }

    @Ignore
    @Test
    public void removeTest2() {
        Map<String, String> m = newInstance();
        m.put("a", "1");
        m.put("b", "2");
        m.remove("b");
        assertNull(m.get("b"));
        assertEquals("1", m.get("a"));
    }

    @Ignore
    @Test
    public void removeTest3() {
        Map<String, String> m = newInstance();
        m.put("h", "8");
        m.put("d", "4");
        m.put("j", "10");
        m.put("b", "2");
        m.put("f", "6");
        m.put("a", "1");
        m.put("c", "3");
        m.put("e", "5");
        m.put("g", "7");
        m.put("i", "9");
        m.put("k", "11");
        m.remove("d");
        assertNull(m.get("d"));
        assertEquals("3", m.get("c"));
        assertEquals("5", m.get("e"));
    }

    @Ignore
    @Test
    public void firstEntryTest() {
        Map<String, String> m = newInstance();
        m.put("h", "8");
        m.put("d", "4");
        m.put("j", "10");
        m.put("b", "2");
        m.put("f", "6");
        m.put("a", "1");
        m.put("c", "3");
        m.put("e", "5");
        m.put("g", "7");
        m.put("i", "9");
        m.put("k", "11");
        Entry<String, String> e = m.firstEntry();
        assertEquals("a", e.getKey());
        assertEquals("1", e.getValue());
    }

    @Ignore
    @Test
    public void ceilingEntryTest1() {
        Map<String, String> m = newInstance();
        m.put("h", "8");
        m.put("d", "4");
        m.put("j", "10");
        m.put("b", "2");
        m.put("f", "6");
        m.put("a", "1");
        m.put("c", "3");
        m.put("e", "5");
        m.put("g", "7");
        m.put("i", "9");
        m.put("k", "11");
        Entry<String, String> e = m.ceilingEntry("g");
        assertEquals("g", e.getKey());
        assertEquals("7", e.getValue());
    }

    @Ignore
    @Test
    public void ceilingEntryTest2() {
        Map<String, String> m = newInstance();
        m.put("h", "8");
        m.put("d", "4");
        m.put("j", "10");
        m.put("b", "2");
        m.put("f", "6");
        m.put("a", "1");
        m.put("c", "3");
        m.put("e", "5");
        m.put("g", "7");
        m.put("i", "9");
        m.put("k", "11");
        Entry<String, String> e = m.ceilingEntry("ga");
        assertEquals("h", e.getKey());
        assertEquals("8", e.getValue());
    }

    @Ignore
    @Test
    public void higherEntryTest1() {
        Map<String, String> m = newInstance();
        m.put("h", "8");
        m.put("d", "4");
        m.put("j", "10");
        m.put("b", "2");
        m.put("f", "6");
        m.put("a", "1");
        m.put("c", "3");
        m.put("e", "5");
        m.put("g", "7");
        m.put("i", "9");
        m.put("k", "11");
        Entry<String, String> e = m.higherEntry("g");
        assertEquals("h", e.getKey());
        assertEquals("8", e.getValue());
    }

    @Ignore
    @Test
    public void higherEntryTest2() {
        Map<String, String> m = newInstance();
        m.put("h", "8");
        m.put("d", "4");
        m.put("j", "10");
        m.put("b", "2");
        m.put("f", "6");
        m.put("a", "1");
        m.put("c", "3");
        m.put("e", "5");
        m.put("g", "7");
        m.put("i", "9");
        m.put("k", "11");
        Entry<String, String> e = m.higherEntry("ga");
        assertEquals("h", e.getKey());
        assertEquals("8", e.getValue());
    }

    /**
     * Testet die Anzahl der Vergleiche, die zum Einfügen in einen Baum benötigt werden.
     * Wenn die Balancierung richtig implementiert ist, dann sollte die Höhe logarithmisch sein.
     */
    @Ignore
    @Test
    public void testBalance() {
        int maxFactor = 100;
        for (int n = 10; n <= 1_000_000; n *= 10) {


            AtomicInteger cmpCount = new AtomicInteger();
            Map<Integer, Integer> m = new RedBlackTree<>((x, y) -> {
                cmpCount.incrementAndGet();
                return x.compareTo(y);
            });

            for (int i = 0; i < n; i++) {
                m.put(i, i);
            }

            for (int i = 2 * n; i >= n; i--) {
                m.put(i, i);
            }

            for (int i = 0; i < 2 * n; i++) {
                assertEquals(Integer.valueOf(i), m.get(i));
            }
            double factor = cmpCount.get() / (n * Math.log(n));
            System.out.printf("%-10d Elemente. Anzahl Vergleiche: %-20d Faktor: %.2f\n", n, cmpCount.get(), factor);
            assertTrue(factor < maxFactor, "Zu viele Vergleichsoperationen! Der Baum ist wahrscheinlich nicht korrekt balanciert.");
        }


    }


}
