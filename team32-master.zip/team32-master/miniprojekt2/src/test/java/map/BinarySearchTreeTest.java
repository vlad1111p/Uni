package map;


import org.junit.Ignore;
import org.junit.Test;

import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class BinarySearchTreeTest {

    private Map<String, String> newInstance() {
        return new BinarySearchTree<>(Comparator.naturalOrder());
    }



    @Test
    public void getEmptyTest() {
        Map<String, String> m = newInstance();
				assertNull(m.get("a"));
    }

   
    @Test
    public void putGetTest1() {
        Map<String, String> m = newInstance();
        m.put("a", "x");
        assertEquals("x", m.get("a"));
    }

   
    @Test
    public void putGetTest2() {
        Map<String, String> m = newInstance();
        m.put("a", "1");
        m.put("b", "2");
        m.put("c", "3");
        m.put("d", "4");
        m.put("e", "5");
        m.put("f", "6");
        m.put("g", "7");
        assertEquals("1", m.get("a"));
        assertEquals("2", m.get("b"));
        assertEquals("3", m.get("c"));
        assertEquals("4", m.get("d"));
        assertEquals("5", m.get("e"));
        assertEquals("6", m.get("f"));
        assertEquals("7", m.get("g"));
    }

   
    @Test
    public void putGetTest3() {
        Map<String, String> m = newInstance();
        m.put("g", "7");
        m.put("f", "6");
        m.put("e", "5");
        m.put("d", "4");
        m.put("c", "3");
        m.put("b", "2");
        m.put("a", "1");
        assertEquals("1", m.get("a"));
        assertEquals("2", m.get("b"));
        assertEquals("3", m.get("c"));
        assertEquals("4", m.get("d"));
        assertEquals("5", m.get("e"));
        assertEquals("6", m.get("f"));
        assertEquals("7", m.get("g"));
    }

   
    @Test
    public void putGetTest4() {
        Map<String, String> m = newInstance();
        m.put("d", "4");
        m.put("f", "6");
        m.put("a", "1");
        m.put("e", "5");
        m.put("c", "3");
        m.put("g", "7");
        m.put("b", "2");
        assertEquals("1", m.get("a"));
        assertEquals("2", m.get("b"));
        assertEquals("3", m.get("c"));
        assertEquals("4", m.get("d"));
        assertEquals("5", m.get("e"));
        assertEquals("6", m.get("f"));
        assertEquals("7", m.get("g"));
    }

   
    @Test
    public void putGetOverrideTest() {
        Map<String, String> m = newInstance();
        m.put("a", "x");
        m.put("a", "y");
        assertEquals("y", m.get("a"));
    }

   
    @Test
    public void removeTest1() {
        Map<String, String> m = newInstance();
        m.put("a", "1");
        m.remove("a");
        assertNull(m.get("a"));
    }

   
    @Test
    public void removeTest2() {
        Map<String, String> m = newInstance();
        m.put("a", "1");
        m.put("b", "2");
        m.remove("b");
        assertNull(m.get("b"));
        assertEquals("1", m.get("a"));
    }

   
    @Test
    public void removeTest3() {
        Map<String, String> m = newInstance();
        m.put("h", "8");
        m.put("d", "4");
        m.put("j", "10");
        m.put("b", "2");
        m.put("f", "6");
        m.put("a", "1");
        m.put("c", "3");
        m.put("e", "5");
        m.put("g", "7");
        m.put("i", "9");
        m.put("k", "11");
        m.remove("d");
        assertNull(m.get("d"));
        assertEquals("3", m.get("c"));
        assertEquals("5", m.get("e"));
    }

   
    @Test
    public void firstEntryTest() {
        Map<String, String> m = newInstance();
        m.put("h", "8");
        m.put("d", "4");
        m.put("j", "10");
        m.put("b", "2");
        m.put("f", "6");
        m.put("a", "1");
        m.put("c", "3");
        m.put("e", "5");
        m.put("g", "7");
        m.put("i", "9");
        m.put("k", "11");
        Entry<String, String> e = m.firstEntry();
        assertEquals("a", e.getKey());
        assertEquals("1", e.getValue());
    }

   
    @Test
    public void ceilingEntryTest1() {
        Map<String, String> m = newInstance();
        m.put("h", "8");
        m.put("d", "4");
        m.put("j", "10");
        m.put("b", "2");
        m.put("f", "6");
        m.put("a", "1");
        m.put("c", "3");
        m.put("e", "5");
        m.put("g", "7");
        m.put("i", "9");
        m.put("k", "11");
        Entry<String, String> e = m.ceilingEntry("g");
        assertEquals("g", e.getKey());
        assertEquals("7", e.getValue());
    }

   
    @Test
    public void ceilingEntryTest2() {
        Map<String, String> m = newInstance();
        m.put("h", "8");
        m.put("d", "4");
        m.put("j", "10");
        m.put("b", "2");
        m.put("f", "6");
        m.put("a", "1");
        m.put("c", "3");
        m.put("e", "5");
        m.put("g", "7");
        m.put("i", "9");
        m.put("k", "11");
        Entry<String, String> e = m.ceilingEntry("ga");
        assertEquals("h", e.getKey());
        assertEquals("8", e.getValue());
    }

   
    @Test
    public void higherEntryTest1() {
        Map<String, String> m = newInstance();
        m.put("h", "8");
        m.put("d", "4");
        m.put("j", "10");
        m.put("b", "2");
        m.put("f", "6");
        m.put("a", "1");
        m.put("c", "3");
        m.put("e", "5");
        m.put("g", "7");
        m.put("i", "9");
        m.put("k", "11");
        Entry<String, String> e = m.higherEntry("g");
        assertEquals("h", e.getKey());
        assertEquals("8", e.getValue());
    }

   
    @Test
    public void higherEntryTest2() {
        Map<String, String> m = newInstance();
        m.put("h", "8");
        m.put("d", "4");
        m.put("j", "10");
        m.put("b", "2");
        m.put("f", "6");
        m.put("a", "1");
        m.put("c", "3");
        m.put("e", "5");
        m.put("g", "7");
        m.put("i", "9");
        m.put("k", "11");
        Entry<String, String> e = m.higherEntry("ga");
        assertEquals("h", e.getKey());
        assertEquals("8", e.getValue());
    }

}
