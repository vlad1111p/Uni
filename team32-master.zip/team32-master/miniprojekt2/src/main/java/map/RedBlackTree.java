package map;

import java.util.Comparator;

import map.BinarySearchTree.Node;

public class RedBlackTree<K, V> implements Map<K, V> {
	// Attributes
	private static final boolean RED = true;
	private static final boolean BLACK = false;
	Comparator<? super K> comper;
	private Node<K, V> root;

	private class Node<K, V> implements Entry<K, V> {
		private K key;
		private V val;
		private Node left, right;
		private boolean color;
		private int size;

		public Node(K key, V val, boolean color, int size) {
			this.key = key;
			this.val = val;
			this.color = color;
			this.size = size;
		}

		@Override
		public K getKey() {
			return key;
		}

		@Override
		public V getValue() {
			return val;
		}
	}

	public RedBlackTree(Comparator<? super K> comparator) {
		comper = comparator;
	}

	private boolean isRed(Node x) {
		if (x == null)
			return false;
		return x.color == RED;
	}

	private int size(Node x) {
		if (x == null)
			return 0;
		return x.size;
	}

	public int size() {
		return size(root);
	}

	@Override
	public void put(K key, V value) {
		root = put(root, key, value);
		root.color = BLACK;
	}

	private Node<K, V> put(Node<K, V> h, K key, V val) {
		if (h == null)
			return new Node(key, val, RED, 1);
		//binary tree normal input
		int cmp = comper.compare(key, h.key);
		if (cmp < 0)
			h.left = put(h.left, key, val);
		else if (cmp > 0)
			h.right = put(h.right, key, val);
		else
			h.val = val;

		// fix-up any right-leaning links
		if (isRed(h.right) && !isRed(h.left))
			h = rotateLeft(h);
		if (isRed(h.left) && isRed(h.left.left))
			h = rotateRight(h);
		if (isRed(h.left) && isRed(h.right))
			flipColors(h);
		h.size = size(h.left) + size(h.right) + 1;

		return h;
	}

	private Node<K, V> rotateRight(Node<K, V> h) {
		// assert (h != null) && isRed(h.left);
		Node<K, V> x = h.left;
		h.left = x.right;
		x.right = h;
		x.color = x.right.color;
		x.right.color = RED;
		x.size = h.size;
		h.size = size(h.left) + size(h.right) + 1;
		return x;
	}

	/*-    X
	 *   a   Y
	        b c
	 */
	// make a right-leaning link lean to the left
	private Node<K, V> rotateLeft(Node<K, V> h) {
		Node<K, V> x = h.right;
		h.right = x.left;
		x.left = h;
		x.color = x.left.color;
		x.left.color = RED;
		x.size = h.size;
		h.size = size(h.left) + size(h.right) + 1;
		return x;
	}

	/*-         Z
	 *       Y   d
	        b c
	 */
	// flip the colors of a node and its two children
	private void flipColors(Node<K, V> h) {
		h.color = !h.color;
		h.left.color = !h.left.color;
		h.right.color = !h.right.color;
	}

	@Override
	public V get(K key) {
		return get(root, key);
	}

	private V get(Node<K, V> x, K key) {
		while (x != null) {
			int cmp = comper.compare(key, x.key);
			if (cmp < 0)
				x = x.left;
			else if (cmp > 0)
				x = x.right;
			else
				return x.val;
		}
		return null;
	}

	@Override
	public void remove(K key) {
		throw new RuntimeException("TODO");
	}

	@Override
	public Entry<K, V> firstEntry() {
		return (Entry<K, V>) firstKey2(root);
	}

	public Node<K, V> firstKey2(Node<K, V> root) {
		Node<K, V> temp = null;
		while (!(root.left == null)) {
			temp = root;
			root = root.left;
		}
		return root;
	}

	@Override
	public Entry<K, V> ceilingEntry(K key) {
		return ceilingEntry2(key, this.root, null);
	}

	public Node<K, V> ceilingEntry2(K key, Node<K, V> root, Node<K, V> prev) {
		if (root == null) {
			return prev;
		} else if (comper.compare(key, root.key) < 0) {
			return ceilingEntry2(key, root.left, root);
		} else if (comper.compare(key, root.key) > 0) {
			return ceilingEntry2(key, root.right, prev);
		} else {
			return root;
		}
	}

	@Override
	public Entry<K, V> higherEntry(K key) {
		return higherKey2(key, this.root, null);
	}

	public Node<K, V> higherKey2(K key, Node<K, V> root, Node<K, V> prev) {
		if (root == null) {
			return prev;
		} else if (comper.compare(key, root.key) < 0) {
			return higherKey2(key, root.left, root);
		} else {
			return higherKey2(key, root.right, prev);
		}
	}

}
