package map;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;


public class App {

	private static Telefonbuch<String, Integer> m;
	static List<map.Entry<String, Integer>> al=new ArrayList<>();
	private static Scanner scu; 

	public static void main(String[] args) {
		m = new Telefonbuch<String, Integer>();

		scu = new Scanner(System.in);
		System.out.print("\n write c to create a contact  ");
		System.out.print("\n write d to delete a contact  ");
		System.out.print("\n write f to find a contact in the contactbook ");
		System.out.print("\n write l to receive a list of all the contacts  ");
		System.out.print("\n write m to show menu ");
		System.out.print("\n write e to exit \n ");
		System.out.print(" write here=  ");
		while (true) {

			String sc = scu.nextLine();
			
			
			if (sc.equals("c")) {
				create();
				System.out.print("\n write m to show menu ");
				System.out.print("\n write here=  \n");
			} 
			else if (sc.equals("d")) {
				System.out.print("\n write the name of the contact =  ");
				
					String key = scu.nextLine();
					m.remove(key);
					System.out.print("\n write m to show menu ");
					System.out.print("\n write here=  \n");
				

			}else if (sc.equals("f")) {
				System.out.print("\n write the name of the contact =  ");
					String key = scu.nextLine();
					System.out.println("the number is " + m.numberfind(key));
					System.out.print("\n write m to show menu ");
					System.out.print("\n write here=  \n");
			}else if (sc.equals("l")) {
				
					al=m.tolist();
					for (int i = 0; i < al.size(); i++) {
						System.out.println(al.get(i).getKey()+"  " + al.get(i).getValue());

					}
					System.out.print("\n write m to show menu ");
					System.out.print("\n write here=  \n");
				}
			else if (sc.equals("m")) {
				System.out.print("\n write c to create a contact  ");
				System.out.print("\n write d to delete a contact  ");
				System.out.print("\n write f to find a contact in the contactbook ");
				System.out.print("\n write l to receive a list of all the contacts  ");
				System.out.print("\n m show menu ");
				System.out.print("\n write e to exit \n ");
				System.out.println(" write here=  ");
			}
				
			else if (sc.equals("e")) {
				System.exit(0);
			}
			
			
		}
	}
	static void create() {
		System.out.print("\n write the name of the contact =  ");

		String key=scu.next();



		System.out.print("\n write the number of the contact =  ");
		
		String line = scu.next();
		
		int number=Integer.parseInt(line);


		m.addcontact(key, number);

    }
}
