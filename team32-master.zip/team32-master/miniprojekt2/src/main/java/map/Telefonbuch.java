package map;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

 

public class Telefonbuch<K,V> {

   
    private BinarySearchTree<String, Integer> contactbook;

    public Telefonbuch(){

	contactbook= new  BinarySearchTree<>(Comparator.naturalOrder());


    }
    void addcontact(String nickname , Integer telefonnummer){
	contactbook.put(nickname, telefonnummer);
    }
    void removecontact(Entry<String, Integer> temp) {
	if(contactbook!=null)
	    if(contactbook.get((String) temp.getKey())!=null) {

		contactbook.remove((String) temp.getKey());  

	    }
    }
    void remove(String nickname) {
    	contactbook.remove(nickname);
    }
    public Integer numberfind(String name) {
	if(contactbook!=null)
	    return contactbook.get(name);
	return null;
    }
    public List<Entry<String, Integer>> tolist() {
	List<Entry<String, Integer>> al=new ArrayList<>();  
	if(contactbook!=null) {
	if(contactbook.firstEntry()!=null) {
	    al.add(contactbook.firstEntry());
	    String iter=contactbook.firstEntry().getKey();
	    if(contactbook.higherEntry(iter)!=null)
	    while(contactbook.higherEntry(iter)!=null) {
	    iter=contactbook.higherEntry(iter).getKey();
		al.add(contactbook.ceilingEntry(iter));
		
	    }

	    return al;
	}
	}
	return null;

    }
}

