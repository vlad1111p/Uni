package map;

import java.util.Comparator;

import map.BinarySearchTree.Node;

public class BinarySearchTree<K, V> implements Map<K, V> {
	public class Node<K, V> implements Entry<K, V> {
		public K key;
		public V value;
		public Node<K, V> left;
		public Node<K, V> right;

		public Node(K key, V value) {
			this.key = key;
			this.value = value;
			this.left = null;
			this.right = null;
		}

		public Node(Node<K, V> left, K key, V value, Node<K, V> right) {
			this.key = key;
			this.value = value;
			this.left = left;
			this.right = right;
		}

		@Override
		public K getKey() {
			return this.key;
		}

		@Override
		public V getValue() {
			return this.value;
		}
	}

	public Node<K, V> root;
	public Comparator<? super K> comper;

	public BinarySearchTree(Comparator<? super K> comper) {
		this.root = null;
		this.comper = comper;
	}

	public void put(K key, V value) {
		root = put2(key, value, root);
	}

	public Node<K, V> put2(K key, V value, Node<K, V> root) {
		if (root == null) {
			return new Node<K, V>(key, value);
		} else if (comper.compare(key, root.key) > 0) {
			root.right = put2(key, value, root.right);
		} else if (comper.compare(key, root.key) < 0) {
			root.left = put2(key, value, root.left);
		} else {
			root.value = value;
		}
		return root;
	}

	public V get(K key) {
		return get2(key, this.root);
	}

	public V get2(K key, Node<K, V> root) {
		if (root == null) {
			return null;
		}
		if (comper.compare(key, root.key) < 0) {
			return get2(key, root.left);
		} else if (comper.compare(key, root.key) > 0) {
			return get2(key, root.right);
		} else {
			return root.value;
		}
	}

	@Override
	public void remove(K key) {
		Node<K, V> temp = (Node<K, V>) root;
		root = remove2(key, temp);
	}

	public Node<K, V> remove2(K key, Node<K, V> root) {
		// Base case tree is empty
		// or key doesn't exist
		if (root == null) {
			return null;
			// key<node.key Go left
		} else if (comper.compare(key, root.key) < 0) {
			root.left = remove2(key, root.left);
			// key>node.key Go Right
		} else if (comper.compare(key, root.key) > 0) {
			root.right = remove2(key, root.right);
			// Node Found
		} else {
			// Base Case one or no children
			if (root.left == null) {
				return root.right;
			} else if (root.right == null) {
				return root.left;
			}
			/*-in case of 2 Childen ,Deleting 11
			 * 		    11
					  /    \
					 5      20
					/ \    /  \
				   2   7  15   25
				      / \     /
				     6   9   24
				     	/
				       8
			 Replacing 11 with a number smaller than all rights, bigger than all lefts
			 =>Biggest number left or smallest number right
			 =>Left child's utmost right works (has 1 child or no children)
			*/
			Node<K, V> temp = root.left;
			while (temp.right != null) {
				temp = temp.right;
			}
			root = new Node<K, V>(root.left, temp.getKey(), temp.getValue(), root.right);
			if (temp.left != null) {
				temp = temp.left;
			} else {
				temp = null;
			}
		}
		return root;
	}

	@Override
	public Entry<K, V> firstEntry() {
		return (Entry<K, V>) firstKey2(root);
	}

	public Node<K, V> firstKey2(Node<K, V> root) {
		Node<K, V> temp = null;
		while (!(root.left == null)) {
			temp = root;
			root = root.left;
		}
		return root;
	}

	@Override
	public Entry<K, V> ceilingEntry(K key) {
		return ceilingEntry2(key, this.root, null);
	}

	public Node<K, V> ceilingEntry2(K key, Node<K, V> root, Node<K, V> prev) {
		if (root == null) {
			return prev;
		} else if (comper.compare(key, root.key) < 0) {
			return ceilingEntry2(key, root.left, root);
		} else if (comper.compare(key, root.key) > 0) {
			return ceilingEntry2(key, root.right, prev);
		} else {
			return root;
		}
	}

	@Override
	public Entry<K, V> higherEntry(K key) {
		return higherKey2(key, this.root, null);
	}

	public Node<K, V> higherKey2(K key, Node<K, V> root, Node<K, V> prev) {
		if (root == null) {
			return prev;
		} else if (comper.compare(key, root.key) < 0) {
			return higherKey2(key, root.left, root);
		} else {
			return higherKey2(key, root.right, prev);
		}
	}
}