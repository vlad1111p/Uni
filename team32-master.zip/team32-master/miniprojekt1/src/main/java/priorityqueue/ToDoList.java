package priorityqueue;

import java.util.Comparator;
import java.util.Scanner;

public class ToDoList {
	String name;

	class paar {
		String text;
		String date;

		paar(String text, String date) {
			this.text = text;
			this.date = date;
		}
	}

	ToDoList() {
		writeName();
	}

	ToDoList(String name) {
		this.name = name;
	}

	Comparator<paar> p = new Comparator<paar>() {
		@Override
		public int compare(paar o1, paar o2) {
			String[] date1 = o1.date.split("\\.");
			String[] date2 = o2.date.split("\\.");
			int date1n = Integer.parseInt(date1[2] + date1[1] + date1[0]);
			int date2n = Integer.parseInt(date2[2] + date2[1] + date2[0]);
			return date1n - date2n;
		}
	};
	LeftistTree<paar> list = new LeftistTree<paar>(p);

	public void writeName() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name:");
		String text = sc.nextLine();
		this.name = text;
	}

	public void add() {
		Scanner sc = new Scanner(System.in);
		System.out.println("adding task and date");
		System.out.println("Enter task");
		String text = sc.nextLine();
		System.out.println("Enter date(dd.mm.yyyy)");
		String date = sc.nextLine();
		add(text, date);
	}

	public void add(String text, String date) {
		paar a = new paar(text, date);
		list.insert(a);
	}

	public void merge(ToDoList b) {
		this.list.merge(b.list);
	}

	public paar deleteMin() {
		paar a = this.list.deleteMin();
		if(a==null) {
			return null;
		}
		System.out.println("task:" + a.text + ",,,,date:" + a.date);
		return a;
	}

	public void print() {
		LeftistTree<paar> tlist = new LeftistTree<paar>(p);
		while (!this.list.isEmpty()) {
			paar a = this.list.deleteMin();
			System.out.println("text:" + a.text + ",,,,date:" + a.date);
			tlist.insert(a);
		}
		this.list = tlist;
	}

}
