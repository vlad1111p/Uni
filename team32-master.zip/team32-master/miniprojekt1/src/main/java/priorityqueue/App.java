package priorityqueue;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class App {// * App2 ist besser ohne user interaction;

	public static boolean inListActions(ToDoList a) {
		System.out.println("Available inList Actions:");
		System.out.println("{1:add task}");
		System.out.println("{2:print}");
		System.out.println("{3:deleteMin}");
		System.out.println("{4:exit list}");
		System.out.println("5.exit programm");
		while (true) {
			System.out.println("currently in list " + "\"" + a.name + "\"");
			System.out.println("Choose inList Action:");
			Scanner sc = new Scanner(System.in);
			String choose = sc.nextLine();
			int chooseint = Integer.parseInt(choose);
			switch (chooseint) {
			case 1:
				a.add();
				break;
			case 2:
				a.print();
				break;
			case 3:
				a.deleteMin();
				break;
			case 4:
				return false;
			case 5:
				return true;
			}
		}
	}

	public static void main(String[] args) {
		boolean exit = false;
		List<ToDoList> list = new LinkedList<ToDoList>();
		System.out.println("Available Managing Actions:");
		System.out.println("1:Create a new ToDoList");
		System.out.println("2:List all ToDoLists");
		System.out.println("3:Select ToDoList");
		System.out.println("4:Merge 2 ToDoList");
		System.out.println("5:Exit Programm");
		while (exit == false) {
			System.out.println("Choose Managing Action:");
			Scanner sc = new Scanner(System.in);
			String choose = sc.nextLine();
			int chooseint = Integer.parseInt(choose);
			switch (chooseint) {
			case 1:
				ToDoList a = new ToDoList();
				list.add(a);
				exit = inListActions(a);
				break;
			case 2:
				int i = 0;
				for (ToDoList e : list) {
					System.out.println(i + ":" + e.name);
					i++;
				}
				break;
			case 3:
				choose = sc.nextLine();
				chooseint = Integer.parseInt(choose);
				exit = inListActions(list.get(chooseint));
			case 4:
				System.out.println("Which lists do you want to merge? (example:'1,2')");
				i = 0;
				for (ToDoList e : list) {
					System.out.println(i + ":" + e.name);
					i++;
				}
				choose = sc.nextLine();
				String[] mergeLists = choose.split(",");
				ToDoList list1 = list.get(Integer.parseInt(mergeLists[0]));
				ToDoList list2 = list.get(Integer.parseInt(mergeLists[1]));
				list1.merge(list2);
				list.remove(list2);
				break;
			case 5:
				exit = true;
				break;
			}
		}
	}
}