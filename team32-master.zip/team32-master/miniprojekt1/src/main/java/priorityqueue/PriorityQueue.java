package priorityqueue;

import java.util.Comparator;

/**
 * This interface contains the necessary operations for a working priority queue.
 *
 * @param <E> item of the priority queue.
 */
public interface PriorityQueue<E> {

    /**
     * Inserts an element into this priority queue.
     *
     * @param e the event to be inserted
     * @return true if the offer was successful
     */
    boolean insert(E e);

    /**
     * Merges a {@link PriorityQueue} into this one.
     *
     * @param q other Queue to merge with
     */
    void merge(PriorityQueue<E> q);

    /**
     * Removes the element at the top of the queue.
     *
     * @return the topmost element of this priority queue
     */
    E deleteMin();

    /**
     * Returns the topmost element of this priority queue without removing it.
     *
     * @return the topmost element of this priority queue
     */
    E getMin();

    /**
     * @return true if this queue is empty.
     */
    boolean isEmpty();

}
