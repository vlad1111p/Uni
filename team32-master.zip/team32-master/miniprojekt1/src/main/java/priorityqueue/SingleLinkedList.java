package priorityqueue;

import java.util.Comparator;

public class SingleLinkedList<E> implements PriorityQueue<E>, Comparator<E> {

    class Link {
	public E data;
	public Link next;

	Link(E e) {
	    data = e;
	    next = null;
	}

    }

    public Comparator<? super E> compe;

    public Link first;
    public Link last;

    public SingleLinkedList(Comparator<? super E> comper) {
	super();

	this.compe = comper;
	last = null;
	first = null;
    }

    @Override
    public boolean insert(E e) {
	Link newdata = new Link(e);

	newdata.next = first;
	first = newdata;

	return true;
    }

    @Override
    public void merge(PriorityQueue<E> q) {
	if (q instanceof SingleLinkedList<?>) {
	    while(!q.isEmpty()) {
		this.insert(q.deleteMin());
	    }
	}
	if (q instanceof PriorityQueue<?>) {
	    while(!q.isEmpty()) {
		this.insert(q.deleteMin());
	    }
	}

    }

    @Override
    public E deleteMin() {
	Link current = first;
	E min = getMin();
	Link next1 = first;
	
	
	if(first.next==null) {
	    E temp=first.data;
	    first=null;
	    return temp;
	}
	if(compare(first.data,min)==0) {
	    E temp=first.data;
	    first=first.next;
	    return temp;
	}
	while (current.next != null && compare(current.data, min) != 0) {
	    next1 = current;
	    current = current.next;
	}
	E temp = current.data;
	if (next1.next.next == null) {
	    next1.next = null;
	    return temp;
	} else {
	    next1.next = next1.next.next;

	    return temp;
	}

    }

    @Override
    public E getMin() {
	
	

	Link current = first;
	E temp = current.data;
	while (current.next != null) {
	    if(compare(temp,current.next.data)>0)
		temp=current.next.data;
	    current=current.next;
	}
	return temp;

    }

    @Override
    public boolean isEmpty() {

	return first == null;
    }

    @Override
    public int compare(E o1, E o2) {
	return compe.compare(o1, o2);

    }


}