package priorityqueue;

import java.util.Comparator;

public class LeftistTree<E> implements PriorityQueue<E>, Comparator<E> {

    public Comparator<? super E> compe;
    public node root;

    class node {
	E data;
	int rank;
	node left;
	node right;

	public node(E element) {
	    this(null, element, null);
	}

	public node(node left, E ele, node right) {
	    this.data = ele;
	    this.left = left;
	    this.right = right;
	    this.rank = 0;
	    if (this.left != null && this.right != null) {
		this.rank = this.calculaterank();
		switche(this);
	    }

	}

	public void switche(node e) {
	    int v = e.left.rank;
	    int m = e.right.rank;
	    if (v < m && e.left != null && e.right != null) {
		node temp = e.right;
		e.right = e.left;
		e.left = temp;
	    }

	}

	public int calculaterank() {

	    if (this.left != null && this.right != null) {

		if (this.left.rank < this.right.rank) {
		    this.rank = 1 + this.left.rank;

		} else {
		    this.rank = 1 + this.right.rank;

		}
	    } else {
		this.rank = 0;

	    }
	    return this.rank;
	}

    }

    public LeftistTree(Comparator<? super E> comper) {
	super();
	this.compe = comper;
	this.root = null;
    }

    public node merge(node e, node m) {

	if (e == null)
	    return m;
	if (m == null)
	    return e;
	if (compare(e.data, m.data) <= 0) {
	    return new node(e.left, e.data, merge(e.right, m));
	} else {
	    return new node(m.left, m.data, merge(m.right, e));
	}
    }

    @Override
    public boolean insert(E e) {

	this.root = merge(new node(e), root);

	return true;
    }

    @Override
    public void merge(PriorityQueue<E> q) {

	if (q instanceof LeftistTree<?>) {
	    while (!q.isEmpty()) {
		this.insert(q.deleteMin());
	    }
	}
	if (q instanceof PriorityQueue<?>) {
	    while (!q.isEmpty()) {
		this.insert(q.deleteMin());
	    }
	}

    }

    @Override
    public E deleteMin() {
	if (!isEmpty()) {
	    E min = root.data;
	    root = merge(root.left, root.right);
	    return min;
	}
	return null;
    }

    @Override
    public E getMin() {

	return root.data;
    }

    @Override
    public boolean isEmpty() {
	return root == null;
    }

 

    @Override
    public int compare(E o1, E o2) {
	return compe.compare(o1, o2);

    }

}
