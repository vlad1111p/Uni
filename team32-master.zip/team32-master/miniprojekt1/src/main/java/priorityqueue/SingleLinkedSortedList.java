package priorityqueue;

import java.util.Comparator;

public class SingleLinkedSortedList<E> implements PriorityQueue<E>, Comparator<E> {

	class Link {
		public E data;
		public Link next;

		Link(E e) {
			data = e;
			next = null;
		}
	}

	public Comparator<? super E> compe;

	public Link first;
	public Link last;

	public SingleLinkedSortedList(Comparator<? super E> comper) {
		super();

		this.compe = comper;
		last = null;
		first = null;
	}

	@Override
	public boolean insert(E e) {

		Link newdata = new Link(e);

		if (first == null || compare(first.data, newdata.data) >= 0) {
			newdata.next = first;
			first = newdata;
		} else {
			Link current = first;

			while (current.next != null && compare(current.next.data, newdata.data) < 0) {
				current = current.next;
			}
			newdata.next = current.next;
			current.next = newdata;
		}

		return true;
	}

	@Override
	public void merge(PriorityQueue<E> q) {
		if (q instanceof SingleLinkedSortedList<?>) {
			while (!q.isEmpty()) {
				this.insert(q.deleteMin());
			}
		}
		if (q instanceof PriorityQueue<?>) {
			while (!q.isEmpty()) {
				this.insert(q.deleteMin());
			}
		}

	}

	@Override
	public E deleteMin() {

		E data = first.data;
		first = first.next;

		return data;

	}

	@Override
	public E getMin() {

		return first.data;
	}

	@Override
	public boolean isEmpty() {
		return first == null;

	}

	@Override
	public int compare(E o1, E o2) {
		return compe.compare(o1, o2);
	}
}
