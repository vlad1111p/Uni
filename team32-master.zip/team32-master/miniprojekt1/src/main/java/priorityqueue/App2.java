package priorityqueue;

public class App2 {

	public static void main(String[] args) {
		ToDoList a = new ToDoList("work");
		ToDoList b = new ToDoList("house");
		a.add("Homework", "10.05.2019");
		a.add("Buy Stuff", "05.05.2019");
		a.add("Organize", "01.05.2011");
		a.add("Sleep", "07.05.2019");
		b.add("Nothing to Do", "01.04.2012");
		a.merge(b);
		a.print();

	}

}
