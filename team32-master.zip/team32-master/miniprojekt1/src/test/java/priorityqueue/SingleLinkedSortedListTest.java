package priorityqueue;


import java.util.Comparator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;

public class SingleLinkedSortedListTest {

    private PriorityQueue<Integer> slsl;

    @BeforeEach
    void initAnewBeforeEach() {
        slsl = new SingleLinkedSortedList<Integer>(Comparator.naturalOrder());
    }

    @Test
    void isEmptyTest() {
        assertTrue(slsl.isEmpty());
    }

    @Test
    void simpleInsertionDeletionGetTest() {
        slsl.insert(2);
        slsl.insert(4);
        slsl.insert(20);
        slsl.insert(1);
        slsl.insert(5);

        assertEquals(1, slsl.getMin().intValue());
        assertEquals(1, slsl.deleteMin().intValue());
        assertEquals(2, slsl.getMin().intValue());
        assertEquals(2, slsl.deleteMin().intValue());
        assertEquals(4, slsl.getMin().intValue());
        assertEquals(4, slsl.deleteMin().intValue());
        assertEquals(5, slsl.getMin().intValue());
        assertEquals(5, slsl.deleteMin().intValue());
        assertEquals(20, slsl.getMin().intValue());
        assertEquals(20, slsl.deleteMin().intValue());
        assertTrue(slsl.isEmpty());
    }

    @Test
    void simpleInsertionGetTest() {
        for (int i = 100; i > 0; i--) {
            slsl.insert(-i);
            assertEquals(-100, slsl.getMin().intValue());
        }
    }

    @Test
    void simpleInsertionDeletionTest() {
        for (int i = 100; i > 0; i--) {
            slsl.insert(-i);
        }
        for (int i = 100; i > 0; i--) {
            assertEquals(-i, slsl.deleteMin().intValue());
        }
    }

    @Test
    void simpleMergeTest() {
        PriorityQueue<Integer> lt2m = new SingleLinkedSortedList<Integer>(Comparator.naturalOrder());
        for (int i = 1; i < 100; i += 2) {
            slsl.insert(i);
            lt2m.insert(i - 1);
        }
        slsl.merge(lt2m);
        for (int i = 0; i < 100; i++) {
            assertEquals(i, slsl.deleteMin().intValue());
        }
    }

    @Test
    void mergeEmtpyTest1() {
        PriorityQueue<Integer> lt2m = new SingleLinkedSortedList<Integer>(Comparator.naturalOrder());
        for (int i = 1; i < 100; i += 2) {
            lt2m.insert(i - 1);
        }
        slsl.merge(lt2m);
        for (int i = 0; i < 99; i += 2) {
            assertEquals(i, slsl.deleteMin().intValue());
        }
    }

    @Test
    void mergeEmtpyTest2() {
        PriorityQueue<Integer> lt2m = new SingleLinkedSortedList<Integer>(Comparator.naturalOrder());
        slsl.merge(lt2m);
        assertTrue(slsl.isEmpty());
    }

    @Test
    void mergeEmtpyTest3() {
        PriorityQueue<Integer> lt2m = new SingleLinkedSortedList<Integer>(Comparator.naturalOrder());
        for (int i = 100; i > 0; i--) {
            slsl.insert(-i);
        }
        slsl.merge(lt2m);
        for (int i = 100; i > 0; i--) {
            assertEquals(-i, slsl.deleteMin().intValue());
        }
    }
}
