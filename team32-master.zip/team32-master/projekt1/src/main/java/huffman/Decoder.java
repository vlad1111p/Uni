package huffman;

import map.Map;
import priorityqueue.PriorityQueue;

public class Decoder {
	String decode = "";

	public String decode(Map<String, Character> reversedMap, String text) {
		String decodedmessage = new String("");
		for (Character c : text.toCharArray()) {
			decode = decode + "" + c;
			if (reversedMap.get(decode) != null) {
				decodedmessage = decodedmessage + reversedMap.get(decode);
				decode = "";
			}
		}
		return decodedmessage;
	}

	public String decode(Map<String, Character> reversedMap, int text) {
		String binary = intToString(text);
		return decode(reversedMap, binary);
	}

	public String intToString(int num) {
		String text = Integer.toBinaryString(num);
		while (text.length() != 8) {
			text = "0" + text;
		}
		return text;
	}

	public String advancedDecode(Map<String, Character> reversedMap, int lastBlock, int lastBlockOccupiedBits) {
		String binary = intToString(lastBlock);
		binary = binary.substring(0,lastBlockOccupiedBits);
		return decode(reversedMap, binary);
	}
	public String decode(PriorityQueue<Node> huffmanBaum, String codedtext) {
		Map<Character,String> map=Huffman.createCodingMap(huffmanBaum);
		Map<String,Character> reversedMap=Huffman.reverseCodingMap(map);
		return decode(reversedMap,codedtext);
	}

	public String decode(PriorityQueue<Node> huffmanBaum, int parseInt) {
		Map<Character,String> map=Huffman.createCodingMap(huffmanBaum);
		Map<String,Character> reversedMap=Huffman.reverseCodingMap(map);
		return decode(reversedMap,parseInt);
	}
}