package huffman;

import map.Entry;

public class Node implements Entry<Character, Integer> {
	public Character key;
	public Integer value;
	private Node left, right;

	public Node(Character key, Integer value) {
		this.setLeft(null);
		this.key = key;
		this.value = value;
		this.setRight(null);
	}
	public Node(Node left, Character key, Integer value, Node right) {
		this.setLeft(left);
		this.key = key;
		this.value = value;
		this.setRight(right);
	}
	public boolean isLeaf(){
		if(left==null&&right==null){
			return true;
		}
		return false;
	}
	public void setLeft(Node left) {
		this.left = left;
	}

	public void setRight(Node right) {
		this.right = right;
	}

	public Character getKey() {
		return key;
	}

	public Integer getValue() {
		return value;
	}

	public Node getLeft() {
		return this.left;
	}

	public Node getRight() {
		return this.right;
	}

	public String print(Node root){
		if(root!=null){
			String text=("{"+root.key+","+ root.value+"}" +"  ");
			return print(root.getLeft())+text+print(root.getRight());
		}
		return "";
	}
	public String print(){
		return print(this);
	}
	@Override public String toString(){
		return print();
	}
}