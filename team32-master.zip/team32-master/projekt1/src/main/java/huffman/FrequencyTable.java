package huffman;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Comparator;

import map.BinarySearchTree;
import map.Map;

public class FrequencyTable {
	Map<Character, Integer> frequencyTable = new BinarySearchTree<>(Comparator.naturalOrder());

	public void createCharFrequencyTable(String text) {
		for (Character currentChar : text.toCharArray()) {
			Integer charFrequency = frequencyTable.get(currentChar);
			// Character doesn't exist in Map
			if (charFrequency == null) {
				charFrequency = 0;
			}
			// Increment character frequency in Map
			frequencyTable.put(currentChar, charFrequency + 1);
		}
	}

	public void createCharFrequencyTablefromFile(FileInputStream in) throws IOException {
		int readedChar;
		while ((readedChar = in.read()) != -1) {
			char readedCharfromint = (char) readedChar;
			createCharFrequencyTable("" + readedCharfromint);
		}
	}



}