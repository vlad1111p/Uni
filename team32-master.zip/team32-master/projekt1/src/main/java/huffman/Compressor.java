package huffman;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import map.Entry;
import map.Map;
import priorityqueue.PriorityQueue;

public class Compressor {
	Map<Character, String> createMapfromInput(FileInputStream in) throws IOException {
		FrequencyTable table = new FrequencyTable();
		table.createCharFrequencyTablefromFile(in);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(table.frequencyTable);
		Map<Character, String> map = Huffman.createCodingMap(huffmanBaum);
		Entry<Character, String> entry = map.firstEntry();
		Huffman.tabletoFile(map);
		map = Huffman.mapfromFile();
		return map;
	}

	public int addBinaryStringtoInt(int number, int occupiedBits, char c) throws IOException {
		int temp = Integer.parseInt("" + c, 2);
		temp = temp << (8 - (occupiedBits + 1));
		number = number | temp;
		return number;
	}

	// Aufgabe7
	public void compress(String text) throws IOException {
		String[] files = text.split(" ");
		FileInputStream in = null;
		FileOutputStream out = null;
		try {
			in = new FileInputStream(files[0]);
			out = new FileOutputStream(files[1]);
			// Step2 make map from Frequency Table
			Map<Character, String> map = createMapfromInput(in);
			// Step3 convert text and write them to file;
			int readedChar;
			int passedInt = 0;
			int occupiedBits = 0;
			in = new FileInputStream(files[0]);
			while ((readedChar = in.read()) != -1) {
				Character character = (char) readedChar;
				String charCoding = map.get(character);
				for (Character s : charCoding.toCharArray()) {
					passedInt = addBinaryStringtoInt(passedInt, occupiedBits, s);
					occupiedBits++;
					if (occupiedBits == 8) {
						out.write(passedInt);
						passedInt = 0;
						occupiedBits = 0;
					}
				}
			}
			out.write(passedInt);
			out.write(occupiedBits);
		} finally {
			if (in != null) {
				in.close();
			}
			if (out != null) {
				out.close();
			}
		}
		return;
	}
}