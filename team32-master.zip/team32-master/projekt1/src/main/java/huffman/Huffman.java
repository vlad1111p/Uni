package huffman;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

import map.Map;
import priorityqueue.PriorityQueue;
import priorityqueue.SingleLinkedSortedList;
import map.Entry;
import map.BinarySearchTree;

public class Huffman {
	// Aufgabe 1
	public static Map<Character, Integer> createCharFrequencyTable(String text) {
		FrequencyTable table = new FrequencyTable();
		table.createCharFrequencyTable(text);
		return table.frequencyTable;

	}

	// Aufgabe 2
	public static Map<String, Integer> getWordFrequency(String text) {
		return null;
	}

	// Aufgabe 3
	public static PriorityQueue<Node> makeHuffmanBaum(Map<Character, Integer> frequencyTable) {
		// Node Comparator, to sort them in Queue
		NodeComparator nodeComparator = new NodeComparator();
		PriorityQueue<Node> huffmanQueue = new SingleLinkedSortedList<>(nodeComparator);
		// Nodes in Queue hinzufühen
		while (frequencyTable.firstEntry() != null) {
			Entry<Character, Integer> entry = frequencyTable.firstEntry();
			frequencyTable.remove(entry.getKey());
			Node node = new Node(entry.getKey(), entry.getValue());
			huffmanQueue.insert(node);
		}
		// Nodes in Queue bearbeiten
		Node min1 = null;
		while (huffmanQueue.getMin() != null) {
			min1 = huffmanQueue.deleteMin();
			Node min2 = huffmanQueue.deleteMin();
			if (min2 == null) {
				huffmanQueue.insert(min1);
				break;
			}
			Node minCompined = new Node(min1, null, min1.value + min2.value, min2);
			huffmanQueue.insert(minCompined);
		}
		if (min1.getLeft() == null && min1.getRight() == null) {
			Node n = new Node(null, min1.getValue());
			n.setLeft(min1);
			huffmanQueue.deleteMin();
			huffmanQueue.insert(n);
		}
		return huffmanQueue;
	}

	// Aufgabe 4
	public static String code(PriorityQueue<Node> huffmanBaum, String text) {
		char[] textArray = text.toCharArray();
		Map<Character, String> codingMap = createCodingMap(huffmanBaum);
		String codedText = "";
		for (int i = 0; i < textArray.length; i++) {
			codedText = codedText + codingMap.get(textArray[i]);
		}
		return codedText;
	}

	// Aufgabe 4 Coding Map from HuffmanBaum
	public static Map<Character, String> createCodingMap(PriorityQueue<Node> queue) {
		Map<Character, String> codingMap = new BinarySearchTree<>(Comparator.naturalOrder());
		Node node = queue.getMin();
		codingMap = createCodingMap("", node, codingMap);
		return codingMap;
	}

	public static Map<Character, String> createCodingMap(String n, Node node, Map<Character, String> map) {
		if (node.getLeft() == null && node.getRight() == null) {// leaf
			map.put(node.key, n);
			return map;
		}
		if (node.getLeft() != null) {
			map = createCodingMap(n + "0", node.getLeft(), map);
		}
		if (node.getRight() != null) {
			map = createCodingMap(n + "1", node.getRight(), map);
		}
		return map;
	}

	// Aufgabe 4 HuffmanBaum from Coding Map
	public static Map<String, Character> reverseCodingMap(Map<Character, String> codingMap) {
		Map<String, Character> reversedMap = new BinarySearchTree<>(Comparator.naturalOrder());
		while (codingMap.firstEntry() != null) {
			Entry<Character, String> entry = codingMap.firstEntry();
			reversedMap.put(entry.getValue(), entry.getKey());
			codingMap.remove(entry.getKey());
		}
		return reversedMap;
	}

	// Aufgabe 5
	public static String decode(Map<String, Character> reversedMap, String text) {
		Decoder decode = new Decoder();
		return decode.decode(reversedMap, text);
	}

	// TODO Aufgabe 6 //Input/Outbut and Streams
	// Kodierungstabelle als file ausgabe
	public static String code(String text) throws IOException {
		Map<Character, Integer> frequencyTable = createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanQueue = makeHuffmanBaum(frequencyTable);
		Map<Character, String> codingMap = createCodingMap(huffmanQueue);
		String codedtext = code(huffmanQueue, text);
		tabletoFile(codingMap);
		return codedtext;
	}

	public static void tabletoFile(Map<Character, String> codingMap) throws IOException {
		FileWriter outputStream = null;
		try {
			outputStream = new FileWriter("CodingTable.txt");
			int c;
			while (codingMap.firstEntry() != null) {
				Entry<Character, String> entry = codingMap.firstEntry();
				codingMap.remove(entry.getKey());
				outputStream.write(Integer.toString(entry.getKey()));
				outputStream.write("(:SplittingPattern:)");
				outputStream.write(entry.getValue());
				outputStream.write("\n");
			}
		} finally {
			if (outputStream != null) {
				outputStream.close();
			}
		}
	}

	public static String decode(String text) throws IOException {
		Decoder decoder = new Decoder();
		Map<Character, String> CodingTable = mapfromFile();
		Map<String, Character> reversedMap = reverseCodingMap(CodingTable);
		return decoder.decode(reversedMap, text);
	}

	public static Map<Character, String> mapfromFile() throws IOException {
		BufferedReader inputStream = null;
		Map<Character, String> CodingTable = new BinarySearchTree<>(Comparator.naturalOrder());
		try {
			inputStream = new BufferedReader(new FileReader("CodingTable.txt"));
			String l;
			while ((l = inputStream.readLine()) != null) {

				String[] entry = l.split("\\(:SplittingPattern:\\)");
				Character c = (char) Integer.parseInt(entry[0]);
				CodingTable.put(c, entry[1]);
			}
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
		}
		return CodingTable;
	}

	public static String decode(PriorityQueue<Node> huffmanBaum, String codedtext) {
		Decoder decode = new Decoder();
		return decode.decode(huffmanBaum, codedtext);
	}
}
