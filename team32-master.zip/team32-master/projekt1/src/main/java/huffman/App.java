package huffman;

import java.io.IOException;
import java.util.Arrays;

public class App {
	//Aufgabe 1 FrequencyTable,Huffman
	//Aufgabe 3 Huffman
	//Aufgabe 4 Huffman
	//Aufgabe 5 Decoder
	//Aufhabe 6 Huffman
	//Aufgabe 7 Compressor,Decompressor
	public static void main(String[] args) throws IOException {
		String[] operation;
		if (args.length == 3) {
			if (!args[0].equals("--compress") && !args[0].equals("--decompress"))
				throw new IllegalArgumentException("such commands don't exist");
			// args[0]=//--compress or --decompress
			// args[1]=//input.txt or input.hz
			// args[2]=//output.txt or output.hz
			operation = new String[] { args[0], args[1], args[2] };
		} else
			throw new IllegalArgumentException("false number of inputs");
		// System.out.println(Arrays.toString(operation));
		if (operation[0].equals("--compress")) {
			Compressor compress = new Compressor();
			compress.compress(operation[1] + " " + operation[2]);
		} else {
			Decompressor decompress = new Decompressor();
			decompress.decompress(operation[1] + " " + operation[2]);
		}
	}
}
