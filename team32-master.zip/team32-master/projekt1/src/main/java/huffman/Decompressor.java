package huffman;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;

import map.Map;
import priorityqueue.PriorityQueue;

public class Decompressor {
	public LinkedList<Integer> convertStringtoInt(String text){
		LinkedList<Integer> list=new LinkedList<Integer>();
		for(Character c:text.toCharArray()){
			list.add((int)c);
			//list.add((int)c>>8);
		}
		return list;
	}
	// --decompress input.hz output.txt
	public void decompress(String file) throws IOException {
		String[] files=file.split(" ");
		FileInputStream in = null;
		FileOutputStream out = null;
		// Step1 Create Frequency Table
		Map<Character, String> codingMap = Huffman.mapfromFile();
		try {
			Map<String, Character> reversedMap = Huffman.reverseCodingMap(codingMap);
			in = new FileInputStream(files[0]);
			out = new FileOutputStream(files[1]);
			int readedChar;
			Decoder decoder = new Decoder();
			int count=0;
			int readed1= in.read();
			int readed2=in.read();
			while ((readedChar = in.read()) != -1) {
				if(count==0){
					String text=decoder.decode(reversedMap,readed1);
					for(int c: convertStringtoInt(text)){
						out.write(c);
					}
					readed1=readedChar;
				}else{
					String text=decoder.decode(reversedMap,readed2);
					for(int c: convertStringtoInt(text)){
						out.write(c);
					}
					readed2=readedChar;
				}
				count++;
				count=count%2;
			}
			int lastblock;
			int occupiedbits;
			if(count==1){
				lastblock=readed2;
				occupiedbits=readed1;
			}else{
				lastblock=readed1;
				occupiedbits=readed2;	
			}
			String text=decoder.advancedDecode(reversedMap,lastblock,occupiedbits);
			for(int c: convertStringtoInt(text)){
				out.write(c);
			}

		} finally {
			if (in != null) {
				in.close();
			}
			if (out != null) {
				out.close();
			}
		}
		return;
	}

}
