package map;

public interface Map<K, V> {

    void put(K key, V i);

    V get(K key);

    void remove(K key);

    Entry<K, V> firstEntry();

    Entry<K, V> ceilingEntry(K key);

    Entry<K, V> higherEntry(K key);
}