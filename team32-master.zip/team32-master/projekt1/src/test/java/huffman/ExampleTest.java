package huffman;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

import org.junit.Ignore;
import org.junit.Test;

import map.BinarySearchTree;
import map.Map;
import priorityqueue.PriorityQueue;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Dies ist ein Beispiel-Test, den Sie als Vorlage für Ihre eigenen Tests
 * verwenden können.
 */

public class ExampleTest {

	@Test
	public void exampleTest() {
		assertEquals(42, 7 * 6);
	}

	// Assert.assertArrayEquals() for arrays
	@Test
	// aufgabe 1
	public void frequencyTable1() {
		Map<Character, Integer> frequencyM;
		String text = "caaacbbaaca";
		frequencyM = Huffman.createCharFrequencyTable(text);
		assertEquals(6, frequencyM.get('a').intValue());
		assertEquals(2, frequencyM.get('b').intValue());
		assertEquals(3, frequencyM.get('c').intValue());
	}

	// aufgabe 1
	@Test
	public void frequencyTable2() {
		Map<Character, Integer> frequencyM;
		String text = "xyzrrrty";
		frequencyM = Huffman.createCharFrequencyTable(text);
		assertEquals(1, frequencyM.get('x').intValue());
		assertEquals(2, frequencyM.get('y').intValue());
		assertEquals(1, frequencyM.get('z').intValue());
		assertEquals(3, frequencyM.get('r').intValue());
		assertEquals(1, frequencyM.get('t').intValue());
		System.out.println("HELLO wORLD");
		System.out.println(frequencyM.toString());
	}

	// aufgabe 3
	@Test
	public void huffmanBaum1() {
		Map<Character, Integer> frequencyM;
		String text = "xyzrrrty";
		frequencyM = Huffman.createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(frequencyM);
		Map<Character, String> map = Huffman.createCodingMap(huffmanBaum);
		int value = huffmanBaum.getMin().getValue();
		assertEquals(8, value);
		System.out.println(map.toString());
	}

	// Aufgabe3
	@Test
	public void huffmanBaum2() {
		Map<Character, Integer> frequencyM;
		String text = "";
		for (int i = 0; i < 10; i++) {
			text = text + "a";
		}
		frequencyM = Huffman.createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(frequencyM);
		Map<Character, String> map = Huffman.createCodingMap(huffmanBaum);
		int value = huffmanBaum.getMin().getValue();
		assertEquals(10, value);
		System.out.println(map.toString());
	}

	// Aufgabe4
	@Test
	public void testCoding1() {
		Map<Character, Integer> frequencyM;
		String text = "xyzrrrty";
		frequencyM = Huffman.createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(frequencyM);
		String codedtext = Huffman.code(huffmanBaum, text);
		System.out.println(Huffman.createCodingMap(huffmanBaum).toString());
		assertEquals("111110111000011010", codedtext);
	}

	// Aufgabe4
	@Test
	public void testCoding2() {
		Map<Character, Integer> frequencyM;
		String text = "aaaaabbbbb";
		frequencyM = Huffman.createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(frequencyM);
		String codedtext = Huffman.code(huffmanBaum, text);
		assertEquals("0000011111", codedtext);
	}

	@Test
	public void testCreateCodingMap1() {
		Map<Character, Integer> frequencyM;
		String text = "Berliner Mauer,\n";
		frequencyM = Huffman.createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(frequencyM);
		Map<Character, String> map = Huffman.createCodingMap(huffmanBaum);
		System.out.println(map.toString());

	}

	@Test
	public void testCreateCodingMap2() {
		Map<Character, Integer> frequencyM;
		String text = "AAAAAAaaaaa";
		frequencyM = Huffman.createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(frequencyM);
		Map<Character, String> map = Huffman.createCodingMap(huffmanBaum);
		System.out.println(map.toString());
	}

	// Aufgabe5
	@Test
	public void Aufgabe5teil1() {
		Map<Character, Integer> frequencyM;
		String text = "xyzrrrty";
		frequencyM = Huffman.createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(frequencyM);
		String codedtext = Huffman.code(huffmanBaum, text);
		System.out.println(codedtext);
		assertEquals(text, Huffman.decode(huffmanBaum, codedtext));

	}

	// Aufgabe5
	@Ignore
	@Test
	public void Aufgabe5teil2() {
		Map<Character, Integer> frequencyM;
		String text = "Berliner Mauer \n";
		frequencyM = Huffman.createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(frequencyM);
		String codedtext = Huffman.code(huffmanBaum, text);
		System.out.println(codedtext);
		assertEquals(text, Huffman.decode(huffmanBaum, codedtext));
	}

	// Aufgabe5
	@Ignore
	@Test
	public void Aufgabe5teil3() {
		Map<Character, Integer> frequencyM;
		String text = "\n\n\n\n.....ZReasfd";
		frequencyM = Huffman.createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(frequencyM);
		String codedtext = Huffman.code(huffmanBaum, text);
		System.out.println(codedtext);
		assertEquals(text, Huffman.decode(huffmanBaum, codedtext));
	}

	@Ignore
	// Aufgabe 6 table to file
	@Test
	public void Aufgabe6part1() throws IOException {
		Map<Character, Integer> frequencyM;
		String text = "abccc";
		String codedText = Huffman.code(text);
		System.out.println("Augabe6,teil 1 Coded Text\n " + codedText);
	}

	@Ignore
	// Aufgabe 6
	@Test
	public void Aufgabe6part11() throws IOException {
		Map<Character, Integer> frequencyM;
		String text = "\n\n\n Berliner Mauer\t";
		String codedText = Huffman.code(text);
		System.out.println("Augabe6,teil 11 Coded Text\n " + codedText);
	}

	@Ignore
	// Aufgabe 6
	@Test
	public void Aufgabe6part2() throws IOException {
		Map<Character, Integer> frequencyM;
		String text = "xyzrrrty";
		frequencyM = Huffman.createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(frequencyM);
		Map<Character, String> map = Huffman.createCodingMap(huffmanBaum);
		System.out.println("coding Map:  " + map.toString());
		text = Huffman.code(text);
		System.out.println("coded Text= " + text);
		Map<Character, String> mapfromFile = Huffman.mapfromFile();
		System.out.println("MapfromFile " + mapfromFile);
		String decodedText;
		decodedText = Huffman.decode(text);
		System.out.println(decodedText);
	}

	@Ignore
	// Aufgabe 6
	@Test
	public void Aufgabe6part3() throws IOException {
		Map<Character, Integer> frequencyM;
		String text = "Berline\nr Mauer \n\n\n\n\n\n";
		frequencyM = Huffman.createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(frequencyM);
		Map<Character, String> map = Huffman.createCodingMap(huffmanBaum);
		System.out.println("coding Map:  " + map.toString());
		text = Huffman.code(text);
		System.out.println("coded Text= " + text);
		Map<Character, String> mapfromFile = Huffman.mapfromFile();
		System.out.println("MapfromFile " + mapfromFile);
		String decodedText;
		decodedText = Huffman.decode(text);
		System.out.println(decodedText);
	}

	// Aufgabe7
	@Ignore
	@Test
	public void addBinaryStringtoInt() throws IOException {
		Compressor compress = new Compressor();
		char c = '1';
		int result = compress.addBinaryStringtoInt(0, 31, c);
		System.out.println("result1: " + Integer.toBinaryString(result));

	}

	@Ignore
	@Test
	public void codingTest1() throws IOException {
		// System.out.println(Huffman.code("Berliner Mauer"));
		System.out.println("coded text=  " + Huffman.code("Mauer"));
		Compressor compress = new Compressor();
		compress.compress("");
	}

	@Ignore
	@Test
	public void decodr1() throws IOException {
		Decoder decode = new Decoder();
		Map<Character, Integer> frequencyM;
		String text = "aaaabbbb";
		frequencyM = Huffman.createCharFrequencyTable(text);
		PriorityQueue<Node> huffmanBaum = Huffman.makeHuffmanBaum(frequencyM);
		Map<Character, String> codingMap = Huffman.createCodingMap(huffmanBaum);
		Map<String, Character> reversedMap = Huffman.reverseCodingMap(codingMap);
		String codedtext = Huffman.code(huffmanBaum, text);
		System.out.println("coding following text: " + codedtext);
		System.out.println("coded Text: " + codedtext);
		System.out.println("decoded Text1: " + decode.decode(huffmanBaum, codedtext));
		System.out.println("decoded Text2: " + decode.decode(huffmanBaum, Integer.parseInt(codedtext, 2)));
	}

	@Ignore
	@Test
	public void decodr2() throws IOException {
		Decoder decode = new Decoder();
		Map<Character, String> codingMap = new BinarySearchTree<>(Comparator.naturalOrder());
		codingMap.put('a', "00");
		codingMap.put('b', "01");
		codingMap.put('c', "100");
		codingMap.put('d', "110");
		Map<String, Character> queue = Huffman.reverseCodingMap(codingMap);
		String text = "0001100110";
		String codedtext = decode.decode(queue, text);
		System.out.println(queue.toString());
		System.out.println(codedtext);
	}

	@Test
	public void decodr() throws IOException {
		System.out.println("coded text=  " + Huffman.code("Mauer"));
		Compressor compress = new Compressor();
		compress.compress("input.txt output.hz");
	//	Decompressor decompress = new Decompressor();
	//	decompress.decompress("output.hz project2.rar");
	}
}
