Dies ist ein [Gradle](https://gradle.org/) Projekt.

Sie können das Projekt mit dem folgenden Befehl kompilieren und die Tests ausführen:

    gradle test

Die Test-Ergebnisse befinden sich dann unter [build/reports/tests/test/index.html](./build/reports/tests/test/index.html).
    
Um die Code-Coverage Statistiken zu erstellen kann das Jacoco Plugin für Gradle verwendet werden: 

    gradle test jacocoTestReport
    
Das Ergebnis befindet sich dann unter [build/reports/jacoco/test/html/index.html](./build/reports/jacoco/test/html/index.html).
    
    
Zum Starten der main-Methode in der Klass App gibt es den Befehl:

    gradle run --console=plain
    
Kommandozeilenparameter lassen sich hier mit der `--args` Option übergeben, zum Beispiel:

    gradle run --console=plain --args='--compress input.txt output.hz'
    
Zum Bauen der ausführbaren jar-Datei `huffman.jar`:

    gradle jar
    
    
### Projektstruktur

Der Code befindet sich unter `src/main/java/huffman` und die Tests unter `src/test/java/huffman`.