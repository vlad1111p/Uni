package weightedgraph;

import org.junit.Test;

public class WeightedGraphTest {
	@Test
	public void Test1() {
		char uniChar = '\uAAA9';
		int uniCharInt=(int)uniChar;
		
		String binaryint=Integer.toBinaryString(uniCharInt);
		System.out.println(uniChar);
		System.out.println(binaryint);
		uniChar = '\u00AA';
	}

}