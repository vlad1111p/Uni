
package weightedgraph;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;

import dijkstra.Dijkstra;
import dijkstra.Dijkstra1;

public class AdjazenListWeightedGraph<T> implements WeightedGraph<T> {
	protected HashMap<T, HashSet<Edge<T>>> graph = new HashMap<>();
	int edgesNumber;
	int verticesNumber;

	@Override
	public void addVertex(T v) {
		graph.put(v, new HashSet<Edge<T>>());
		verticesNumber++;
	}

	@Override
	public void addEdge(T start, T end, int weight) {
		Edge<T> edge = new Edge<>(weight, end);
		HashSet<Edge<T>> edgesSet = graph.get(start);
		edgesSet.add(edge);
		edgesNumber++;
	}

	@Override
	public int numEdges() {
		return edgesNumber;
	}

	@Override
	public int numVertices() {
		return verticesNumber;
	}

	@Override
	public Collection<T> vertices() {
		Collection<T> vertices = new HashSet<T>();
		vertices = graph.keySet();
		return vertices;
	}

	@Override
	public Collection<Edge<T>> neighbors(T v) {
		Collection<Edge<T>> egdges = new HashSet<>();
		egdges = graph.get(v);
		return egdges;

	}

	public static void main(String args[]) {
		WeightedGraph<String> graph = new AdjazenListWeightedGraph<String>();
		graph.addVertex("A");
		graph.addVertex("B");
		graph.addVertex("C");
		graph.addVertex("D");
		graph.addVertex("E");
		graph.addEdge("A", "B", 4);
		graph.addEdge("A", "D", 8);
		graph.addEdge("A", "E", 9);
		graph.addEdge("B", "C", 2);
		graph.addEdge("B", "D", 3);
		graph.addEdge("D", "E", 1);
		graph.addEdge("E", "D", 4);
		System.out.println(graph.numEdges());
		System.out.println(graph.numVertices());
		System.out.println(graph.vertices().toString());
		Collection<Edge<String>> edges = graph.neighbors("A");
		for (Edge<String> e : edges) {
			System.out.println("Edge,Weight=" + e.getEnd() + e.getWeight());
		}
		Dijkstra dj=new Dijkstra(graph,"A");
		System.out.println("Distance to E"+dj.distanceTo("E"));
		System.out.println("Path to E"+dj.shortestPathTo("E").toString());
		Dijkstra1 dj1=new Dijkstra1(graph,"A");
		System.out.println("Distance to E"+dj1.distanceTo("E"));
		System.out.println("Path to E"+dj1.shortestPathTo("E").toString());
	}

}