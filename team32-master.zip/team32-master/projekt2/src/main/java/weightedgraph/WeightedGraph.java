package weightedgraph;
import java.util.Collection;

public interface WeightedGraph<T> {
	public static class Edge<T> {
		private int weight;
		private T end;

		public Edge(int weight, T end) {
			this.weight = weight;
			this.end = end;
		}

		public int getWeight() {
			return weight;
		}

		public T getEnd() {
			return end;
		}
	}

	// Fuegt Knoten hinzu
	void addVertex(T v);

	// Fuegt Kanten hinzu
	void addEdge(T start, T end, int weight);

	// Anzahl der Kanten
	int numEdges();

	// Anzahl der Knoten
	int numVertices();// Liefert alle Knoten

	Collection<T> vertices();

	// Liefert die direkten Nachbarn eines Knotens
	Collection<Edge<T>> neighbors(T v);
}