
package dijkstra;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;

import weightedgraph.WeightedGraph;
import weightedgraph.WeightedGraph.Edge;

public class Dijkstra1 {
	public class Node {
		String v;
		int distance = Integer.MAX_VALUE;
		boolean visited = false;
		String prev=null;

		public Node(String start, int i) {
			this.v = start;
			this.distance = i;
		}

	}

	public class NodeComparator implements Comparator<Node> {
		@Override
		public int compare(Node o1, Node o2) {
			return o1.distance - o2.distance;
		}

	}

	HashMap<String, Integer> distances = new HashMap<>();
	HashMap<String, String> pred = new HashMap<>();

	public Dijkstra1(WeightedGraph<String> graph, String start) {
		PriorityQueue<Node> unsetteledNodes = new PriorityQueue<>(new NodeComparator());
		Set<String> setteledNodes = new HashSet<>();
		distances.put(start, 0);
		pred.put(start, null);
		for (String v : graph.vertices()) {
			if (!v.equals(start)) {
				distances.put(v, Integer.MAX_VALUE);
				pred.put(v, null);
			}
		}
		unsetteledNodes.add(new Node(start, 0));
		while (!unsetteledNodes.isEmpty()) {
			String currentNode = unsetteledNodes.poll().v;
			unsetteledNodes.remove(currentNode);
			for (Edge<String> e : graph.neighbors(currentNode)) {
				String vertic = e.getEnd();
				int oldDistance = distances.get(vertic);
				int tempDistance = distances.get(currentNode) + e.getWeight();
				if (tempDistance < oldDistance) {
					distances.put(vertic, tempDistance);
					pred.put(vertic, currentNode);
				}
				if (!setteledNodes.contains(vertic)) {
					unsetteledNodes.add(new Node(vertic, distances.get(vertic)));
				}
			}
			setteledNodes.add(currentNode);
			System.out.println("Setteled Nodes " + setteledNodes.toString());
			System.out.println("unSetteled Nodes " + unsetteledNodes.toString());
		}
	}

	public int distanceTo(String target) {
		return distances.get(target);
	}

	public List<String> shortestPathTo(String target) {
		List<String> path = new LinkedList<>();
		if (target == null) {
			return path;
		}
		String predecessor = target;
		while (predecessor != null) {
			path.add(0, predecessor);
			predecessor = pred.get(predecessor);
		}
		return path;
	}
}