
package dijkstra;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;

import weightedgraph.WeightedGraph;
import weightedgraph.WeightedGraph.Edge;

public class Dijkstra {
	HashMap<String, Integer> distances = new HashMap<>();
	HashMap<String, String> pred = new HashMap<>();

	public Dijkstra(WeightedGraph<String> graph, String start) {
		Set<String> unsetteledNodes = new HashSet<>();
		Set<String> setteledNodes = new HashSet<>();
		distances.put(start, 0);
		pred.put(start, null);
		for (String v : graph.vertices()) {
			if (!v.equals(start)) {
				distances.put(v, Integer.MAX_VALUE);
				pred.put(v, null);
			}
		}
		unsetteledNodes.add(start);
		while (!unsetteledNodes.isEmpty()) {
			String currentNode = getNodewithMinDistance(unsetteledNodes, distances);
			unsetteledNodes.remove(currentNode);
			for (Edge<String> e : graph.neighbors(currentNode)) {
				String vertic = e.getEnd();
				int oldDistance = distances.get(vertic);
				int tempDistance = distances.get(currentNode) + e.getWeight();
				if (tempDistance < oldDistance) {
					distances.put(vertic, tempDistance);
					pred.put(vertic, currentNode);
				}
				if (!setteledNodes.contains(vertic)) {
					unsetteledNodes.add(vertic);
				}
			}
			setteledNodes.add(currentNode);
			System.out.println("Setteled Nodes " + setteledNodes.toString());
			System.out.println("unSetteled Nodes " + unsetteledNodes.toString());
		}
	}

	public String getNodewithMinDistance(Set<String> unsetteledNodes, HashMap<String, Integer> distances) {
		int min = Integer.MAX_VALUE;
		String smin = null;
		for (String s : unsetteledNodes) {
			if (distances.get(s) < min) {
				min = distances.get(s);
				smin = s;
			}
		}
		return smin;
	}

	public int distanceTo(String target) {
		return distances.get(target);
	}

	public List<String> shortestPathTo(String target) {
		List<String> path = new LinkedList<>();
		if(target==null){
			return path;
		}
		String predecessor=target;
		while (predecessor != null) {
			path.add(0, predecessor);
			predecessor=pred.get(predecessor);
		}
		return path;
	}
}