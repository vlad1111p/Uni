package fahrleitsystem;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import weightedgraph.WeightedGraph;

public class Stadtgraph {
	public static class Edge {
		// (links|rechts) open,unten
		// links bedeuted high to low
		// rechts bedeuted low to high
		// if there is no links, or right, null is writting
		// (rou,null,s1,s2) means no forward possible,s1 turn left ,s2 turn right
		String direction;
		double distance;
		String end;

		public Edge(String direction, double distance, String end) {
			this.direction = direction;
			this.distance = distance;
			this.end = end;
		}

		public String getEnd() {
			return end;
		}

		public String getDirection() {
			return direction;
		}

		public double getDistance() {
			return distance;
		}
	}

	protected HashMap<String, HashSet<Edge>> graph = new HashMap<>();
	HashMap<String,Adresse> adresses=new HashMap<>();
	int edgesNumber;
	int verticesNumber;

	public void addVertex(String v) {
		graph.put(v, new HashSet<Edge>());
		verticesNumber++;
	}
	public void addEdge(String start, String end, double distanceperhouse, String direction) {
		Edge edge = new Edge(direction, distanceperhouse, end);
		HashSet<Edge> edgesSet = graph.get(start);
		edgesSet.add(edge);
		edgesNumber++;
	}

	public int numEdges() {
		return edgesNumber;
	}

	public int numVertices() {
		return verticesNumber;
	}

	public Collection<String> vertices() {
		Collection<String> vertices = new HashSet<>();
		vertices = graph.keySet();
		return vertices;
	}

	public Collection<Edge> neighbors(String v) {
		Collection<Edge> egdges = new HashSet<>();
		egdges = graph.get(v);
		return egdges;
	}

}