
package fahrleitsystem;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;

import fahrleitsystem.Stadtgraph.Edge;

public class DijkstraStadtPlan {

	public class AdresseComparator implements Comparator<Adresse> {
		@Override
		public int compare(Adresse o1, Adresse o2) {
			return (int) (o1.distance - o2.distance);
		}
	}

	Stadtgraph graph;

	public DijkstraStadtPlan(Stadtgraph graph2, String start) {
		this.graph = graph2;
		PriorityQueue<Adresse> unsetteledNodes = new PriorityQueue<>(new AdresseComparator());
		Adresse s = graph.adresses.get(start);
		s.distance = 0;
		s.prev = null;
		unsetteledNodes.add(s);
		while (!unsetteledNodes.isEmpty()) {
			Adresse currentNode = unsetteledNodes.poll();
			unsetteledNodes.remove(currentNode);
			for (Edge e : graph.neighbors(currentNode.adress)) {
				String vertic = e.getEnd();
				Adresse verticadresse = graph.adresses.get(vertic);
				double oldDistance = verticadresse.distance;
				double tempDistance = currentNode.distance + e.distance;
				if (tempDistance < oldDistance) {
					verticadresse.distance = tempDistance;
					verticadresse.prev = currentNode;
					verticadresse.nextDirection = e.direction;
				}
				if (verticadresse.visited == false) {
					unsetteledNodes.add(verticadresse);
				}
			}
			currentNode.visited = true;
		}
	}

	public double distanceTo(String target) {
		return this.graph.adresses.get(target).distance;
	}

	public List<String> shortestPathTo(String target) {
		//List(Adresse1,Adresse2,Adresse3...)
		List<String> path = new LinkedList<>();
		if (target == null) {
			return path;
		}
		Adresse previous = this.graph.adresses.get(target);
		while (previous != null) {
			path.add(0, previous.adress);
			path.add(0, previous.nextDirection);
			previous = previous.prev;
		}
		return path;
	}

	public List<String> shortestPathTo2(String target) {
		//List(Adresse1,RechtungzuAdresse2,Adresse2,RechtungzuAdresse3,Adresse3...)
		List<String> path = new LinkedList<>();
		if (target == null) {
			return path;
		}
		Adresse previous1 = this.graph.adresses.get(target);
		Adresse previous2 = previous1.prev;
		String street;
		int[] intervall = new int[2];
		street = previous1.adressArray[0];
		intervall[0] = Integer.parseInt(previous1.adressArray[1]);
		while (previous2 != null) {
			if (previous1.section.equals(previous2.section)) {
				intervall[1] = Integer.parseInt(previous2.adressArray[1]);
			} else {
				path.add(0, street + " " + intervall[1] + "-" + intervall[0]);
				if (street.equals(previous2.adressArray[0])) {
					path.add(0, "kreuzung überspringen");
				} else {
					path.add(0, "kreuzung " + previous1.nextDirection);
					street = previous2.adressArray[0];
					intervall[0] = Integer.parseInt(previous2.adressArray[1]);
				}
				street = previous2.adressArray[0];
				intervall[0] = Integer.parseInt(previous2.adressArray[1]);
			}
			previous1 = previous2;
			previous2 = previous2.prev;
		}
		path.add(0, street + " " + intervall[1] + "-" + intervall[0]);
		return path;
	}
}