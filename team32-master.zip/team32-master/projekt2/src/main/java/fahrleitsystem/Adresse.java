package fahrleitsystem;

public class Adresse {
	String adress;
	String[] adressArray;
	Adresse prev = null;
	String nextDirection=null;
	double distance = Double.MAX_VALUE;
	boolean visited = false;
	String section=null;

	Adresse(String Adress) {
		this.adress = Adress;
		adressArray=adress.split(" ");
	}
}