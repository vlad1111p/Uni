package fahrleitsystem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import fahrleitsystem.Stadtgraph.Edge;

public class App {
	public static void main(String args[]) throws IOException {
		// test();
		// System.exit(0);
		Scanner scanner = new Scanner(System.in);
		System.out.println("Bitte Startadresse eingeben: ");
		// String start = scanner.nextLine();
		String start = "Tokenring 1";
		System.out.println("Bitte Zieladresse eingeben: ");
		// String ziel = scanner.nextLine();
		String ziel = "Wössnerweg 35";
		String[] adressen = (start + "§" + ziel).split("§");
		Stadtgraph graph = readGraph();
		DijkstraStadtPlan dj = new DijkstraStadtPlan(graph, adressen[0]);
		String destination = adressen[1];
		List<String> path = dj.shortestPathTo2(destination);
		List<String> combined = extractAnweisungen(path);
		for (String s : combined) {
			System.out.println(s);
		}
	}

	public static Stadtgraph readGraph() throws IOException {
		Stadtgraph graph = new Stadtgraph();
		List<String> strassen = mapfromFile();
		HashMap<String, String> leftBound = new HashMap<>();
		HashMap<String, String> rightBound = new HashMap<>();
		for (String s : strassen) {
			String[] ar = s.split(" ");
			// a[0]label,not needed ar[1] =name ar[2]=hausnummern ar[3]=length ar[4]=links
			// neighbours, ar[5]right neighbours;
			// create Street
			int[] hausnummern = new int[2];
			String[] hausNstring = ar[2].split("-");
			hausnummern[0] = Integer.parseInt(hausNstring[0]);
			hausnummern[1] = Integer.parseInt(hausNstring[1]);
			int houseQuantity = hausnummern[1] - hausnummern[0];
			// durchschnittliche Distanz zwischen Häusern
			double distanceperhouse = Double.parseDouble(ar[3].replace("km", "")) / houseQuantity;
			// füge jedes Haus als Knoten zum Stadtplan hinzu und Kanten zu den Häusern im
			// gleichen Abschnitt
			for (int i = hausnummern[0]; i <= hausnummern[1]; i++) {
				String key = ar[1] + " " + i;
				graph.addVertex(key);
				Adresse keyAdress = new Adresse(key);
				keyAdress.section = ar[0];
				graph.adresses.put(key, keyAdress);
			}
			// wenn die Starße vorwärts durchfahren wird
			for (int i = hausnummern[0]; i <= hausnummern[1] - 1; i++) {
				String start = ar[1] + " " + i;
				String end = ar[1] + " " + (i + 1);
				graph.addEdge(start, end, distanceperhouse, "Forward");
			}
			// wenn die Straße rückwärts durchfahren wird
			for (int i = hausnummern[1]; i >= hausnummern[0] + 1; i--) {
				String start = ar[1] + " " + i;
				String end = ar[1] + " " + (i - 1);
				// System.out.println(start + " " + end);
				graph.addEdge(start, end, distanceperhouse, "Backward");
			}
			leftBound.put(ar[0], ar[1] + " " + hausnummern[0]);
			rightBound.put(ar[0], ar[1] + " " + hausnummern[1]);
		}
		// ar[4] ,,ar[5] explanation
		// backward right left
		// forward left right
		// determiner says what was the low-high direction at the beginning and at the
		// end
		rightBound.put(null, null);
		leftBound.put(null, null);
		for (String s : strassen) {
			String[] ar = s.split(" ");
			// finde benachbarte Straßen
			String leftNeighbors = ar[4]; // "Backward{{a8,highest}{d1,lowest}{null,null}}"
			String rightNeighbours = ar[5];
			leftNeighbors = leftNeighbors.replaceAll("Backward\\{\\{", ""); // "a8,highest}{d1,lowest}{null,null}}"
			leftNeighbors = leftNeighbors.replaceAll("\\}\\{", " "); // "a8,highest d1,lowest null,null}}"
			leftNeighbors = leftNeighbors.replaceAll("\\}", ""); // "a8,highest d1,lowest null,null"
			String[] neighbours1 = leftNeighbors.split(" "); // [a8,highest, d1,lowest, null,null]
			rightNeighbours = rightNeighbours.replaceAll("Forward\\{\\{", "");
			rightNeighbours = rightNeighbours.replaceAll("\\}\\{", " ");
			rightNeighbours = rightNeighbours.replaceAll("\\}", "");
			String[] neighbours2 = rightNeighbours.split(" ");
			for (int i = 0; i < 3; i++) {
				String end1 = null;
				String direction1 = null;
				String end2 = null;
				String direction2 = null;

				if (neighbours1[i].split(",")[1].equals("highest")) {
					end1 = rightBound.get(neighbours1[i].split(",")[0]);
				} else if (neighbours1[i].split(",")[1].equals("lowest")) {
					end1 = leftBound.get(neighbours1[i].split(",")[0]);
				}
				if (i == 0) {
					direction1 = "Backwards";
					direction2 = "Forwards";
				} else if (i == 1) {
					direction1 = "Right";
					direction2 = "Right";
				} else {
					direction1 = "Left";
					direction2 = "Left";
				}
				if (neighbours2[i].split(",")[1].equals("highest")) {
					end2 = rightBound.get(neighbours2[i].split(",")[0]);
				} else if (neighbours2[i].split(",")[1].equals("lowest")) {
					end2 = leftBound.get(neighbours2[i].split(",")[0]);
				}
				if (direction1 != null && end1 != null) {
					graph.addEdge(leftBound.get(ar[0]), end1, 0.2, direction1);
				}
				if (direction2 != null && end2 != null) {
					graph.addEdge(rightBound.get(ar[0]), end2, 0.2, direction2);
				}
			}
		}
		return graph;
	}

	public static List<String> mapfromFile() throws IOException {
		List<String> list = new LinkedList<>();
		BufferedReader inputStream = null;
		try {
			inputStream = new BufferedReader(new FileReader("Stadtmap.txt"));
			String l;
			while ((l = inputStream.readLine()) != null) {
				list.add(l);
			}
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
		}
		return list;
	}

	public static List<String> extractAnweisungen(List<String> path) {
		List<String> anweisungen = new LinkedList<>();
		Iterator<String> iter = path.iterator();
		String s = iter.next();
		String[] intervall = s.split(" ")[1].split("-");
		if (Integer.parseInt(intervall[0]) > Integer.parseInt(intervall[1])) {
			anweisungen.add("Fahren Sie in Richtung der hohen Hausnummern");
		} else {
			anweisungen.add("Fahren Sie in Richtung der niedrigen Hausnummern");
		}
		int kreuzungen = 0;
		while (iter.hasNext()) {
			// String prev=s;
			s = iter.next();
			if (s.equals("kreuzung überspringen")) {
				kreuzungen++;
			} else if (s.contains("kreuzung") && kreuzungen > 0) {
				anweisungen.add("überqueren Sie nächsten (" + kreuzungen + ") Kreuzungen ");
				kreuzungen = 0;
			}
			if (s.contains("kreuzung") && !s.contains("überspringen")) {
				String direction = s.split(" ")[1];
				anweisungen.add("biegen Sie an der nächsten Kreuzung " + direction + " ab (" + iter.next() + ")");
			}
		}
		if (kreuzungen > 0) {
			anweisungen.add("überqueren Sie nächsten (" + kreuzungen + ") Kreuzungen ");
		}
		return anweisungen;
	}

	public static void test() throws IOException {
		Stadtgraph graph = readGraph();
		System.out.println("Edges Number " + graph.numEdges());
		System.out.println("Vertices Number " + graph.numVertices());
		Collection<Edge> edges = graph.neighbors("Adaallee 1");
		for (Edge e : edges) {
			System.out.println("Edge,direction,distance=" + e.getEnd() + ", " + e.direction + ", " + e.distance);
		}
		DijkstraStadtPlan dj = new DijkstraStadtPlan(graph, "Am-Turingtor 1");
		String distanation = "Adaallee 1";
		// System.out.println("Path to E" + dj.shortestPathTo(distanation).toString());
		System.out.println("Path to E" + dj.shortestPathTo2(distanation).toString());
		System.out.println("Path to E" + extractAnweisungen(dj.shortestPathTo2(distanation)).toString());

	}
}